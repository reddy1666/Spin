package com.example.kjaye.hello;

import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Result extends AppCompatActivity {
ImageView i1,i2;
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        t1=(TextView)findViewById(R.id.textView2);
        i1=(ImageView)findViewById(R.id.imageView);
        i2=(ImageView)findViewById(R.id.imageView2);
        int i=getIntent().getExtras().getInt("guess");
        int j=getIntent().getExtras().getInt("real");
        if(i==j)
        {
            i1.setImageResource(R.drawable.win);
        }
        else
        {
t1.setText("the correct value is "+j);
        }
        i2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i5=new Intent(Result.this,MainActivity.class);
                startActivity(i5);
            }
        });
    }
}
